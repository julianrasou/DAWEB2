// para limpiar el localstorage para pruebas
// cambiar en el head del html de ejercicio9.js a ejercicio99.js

localStorage.clear();