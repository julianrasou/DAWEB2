let respuesta = prompt("Escriba el nombre de una jugadora.")
if(respuesta == "Luisa" ||respuesta =="María" || respuesta =="Carlota" || respuesta == "Ana"|| respuesta == "Martina"|| respuesta =="Claudia"){
    alert("Está convocada.");
}else alert("No está convocada.");

