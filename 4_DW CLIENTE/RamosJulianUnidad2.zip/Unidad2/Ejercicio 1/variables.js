function variables(){
    let entero = 1357;
    let decimal = 135.7;
    let cientifico = 135e7;
    let octal = 0o1357;
    let hexadecimal = 0x1357;

    console.log("Número entero " + entero);
    console.log("Número decimal " + decimal);
    console.log("Número científico" + cientifico);
    console.log("Número octal " + octal);
    console.log("Número hexadecimal " + hexadecimal);
}

variables()