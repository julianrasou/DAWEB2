do{
    var respuesta = prompt("¿Cuál es el nombre del primer presidente de la democracia?")
}while(respuesta != "Adolfo Suárez")