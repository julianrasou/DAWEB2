let nombre = "julian";
let apellido = "ramos";
let edad = 21;
let nacicmiento = 2003;

window.alert("una frase con 'comillas simples'");
window.alert(nombre + "\n" + apellido);
window.alert(edad + nacicmiento);
window.alert(nombre + apellido + edad + nacicmiento);